package com.psa.flight_reservation_app_5.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PassengerController {

}
