package com.psa.flight_reservation_app_5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightReservationApp5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
